public interface LocationObserver { // Observer 인터페이스
    void onLocationChanged(Location location); // 위치 변경 알림
}