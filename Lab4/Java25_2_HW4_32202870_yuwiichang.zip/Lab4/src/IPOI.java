// yourcode - 데코레이터 패턴의 Component 인터페이스
public interface IPOI {
    String getInformation(); // POI 정보를 문자열로 반환하는 메서드
}
